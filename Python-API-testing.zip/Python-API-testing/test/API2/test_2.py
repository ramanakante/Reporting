from itsdangerous import json
import pytest
import requests
import os
from Authentication import Token
from Utils.Variables import commands2
from Utils.asserter import assert_true,assert_equal
from Utils.urls import api2


current_working_dir = os.path.dirname(os.path.abspath(__file__))
json_file = os.path.join(current_working_dir, '..', '..','utils','Inputs','inputs.json')    
with open(json_file) as f:
    commands_data = json.load(f)




def test_post1():
    current_working_dir = os.path.dirname(os.path.abspath(__file__))
    json_file = os.path.join(current_working_dir, '..', '..','utils','Inputs','token.json')
    with open(json_file) as f:
        auth_token = json.load(f)
    headers = {'Authorization': auth_token}  
          
    input = commands_data
    url = api2
    response = requests.post(url,json=input, headers=headers)    
    assert_equal(response.status_code, 200, f'Status code is {response.status_code} ')
    #Comparing data from diff file (utils/Variables.py)       
    assert response.json()['commands_list'] == commands2

    #Updating Demo_input.json
    current_working_dir = os.path.dirname(os.path.abspath(__file__))
    json_file = os.path.join(current_working_dir, '..', '..','utils','Inputs','Demo_input.json')
    with open(json_file) as f:
        demo_input = json.load(f)
    
    demo_input["support"]["url"] = "https://reqres.in/#support"

    with open(json_file,"w") as f:
        json.dump(demo_input,f)
    
        
        