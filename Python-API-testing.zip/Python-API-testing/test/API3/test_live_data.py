import requests
from Utils.urls import demoApi, usersApi
import os
import json

def test_get():
    response = requests.get(demoApi)    
    current_working_dir = os.path.dirname(os.path.abspath(__file__))
    json_file = os.path.join(current_working_dir, '..', '..','API_Inputs','Demo_input.json')
    with open(json_file,'w') as file_obj:
        json.dump(response.json(),file_obj)

def test_update_input():      
    current_working_dir = os.path.dirname(os.path.abspath(__file__))
    json_file = os.path.join(current_working_dir, '..', '..','API_Inputs','Demo_input.json')
    with open(json_file) as file_obj:
        input_json = json.load(file_obj)
    
    data_list = input_json["data"]
    for data in data_list:
        if data["id"] == 9:
            data["first_name"] = "John"
    input_json["data"] = data_list

    with open(json_file,'w') as file_obj:
        json.dump(input_json,file_obj)

def test_update_website_payload():
    current_working_dir = os.path.dirname(os.path.abspath(__file__))
    json_file = os.path.join(current_working_dir, '..', '..','API_Inputs','Demo_input.json')
    with open(json_file) as file_obj:
        payload = json.load(file_obj)
    response = requests.put(demoApi,json=payload)


def test_create_user():
    payload = {
    "name": "Ramana",
    "job": "leader"
}
    response = requests.post(usersApi,json=payload)

# def test_update_user():
#     payload = {
#     "name": "Ramana",
#     "job": "Manager"
# }
#     response = requests.put(usersApi,json=payload)