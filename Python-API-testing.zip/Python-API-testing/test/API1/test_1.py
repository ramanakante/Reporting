from itsdangerous import json
import pytest
import requests
import os
from Authentication import Token
from Utils.Variables import commands1
from Utils.asserter import assert_true,assert_equal
from Utils.urls import api1


def test_fetch_token():
    auth_token = Token.generate_token()
    current_working_dir = os.path.dirname(os.path.abspath(__file__))
    json_file = os.path.join(current_working_dir, '..', '..','utils','Inputs','token.json')
    with open(json_file,'w') as f:
        json.dump(auth_token,f)


def test_post():
    current_working_dir = os.path.dirname(os.path.abspath(__file__))
    json_file = os.path.join(current_working_dir, '..', '..','utils','Inputs','token.json')
    with open(json_file) as f:
        auth_token = json.load(f)  
         
    headers = {'Authorization': auth_token}

    current_working_dir = os.path.dirname(os.path.abspath(__file__))
    json_file = os.path.join(current_working_dir, '..', '..','utils','Inputs','input1.json')
    with open(json_file) as f:
        payload = json.load(f)     
    input = payload
    #                        (OR)

    # input = {
    #         "pingdata": [
    #         {
    #         "destIP": "10.10.10.10",
    #         "repeat": "5",
    #         "size": "100",
    #         "sourceIP": "gi0/0/1.3204",
    #         "vrf":"",
    #         "timeout": "",
    #         "dscp":""
    #         }                    
    #         ]
    #         }
    url = api1
    response = requests.post(url,json=input, headers=headers) 
    assert_equal(response.status_code, 200, f'Status code is {response.status_code} ')      
    #Comparing data from diff file (utils/Variables.py)   
       
    assert_equal(response.json()['commands_list'],commands1, 'some message')
    # response = {"a":10,"b":20}
    #Updating other testcase input     #    
    current_working_dir = os.path.dirname(os.path.abspath(__file__))
    json_file = os.path.join(current_working_dir, '..', '..','utils','Inputs','inputs.json')    
    with open(json_file) as f:
        commands_data = json.load(f)
    # commands_data['a'] = response['a']
    # commands_data['b'] = response['b']
    required_input = commands_data["pingdata"][0]
    required_input['destIP'] = '127.0.0.1'
    commands_data["pingdata"][0] = required_input

    with open(json_file,'w') as f:        
        json.dump(commands_data,f)
        
        