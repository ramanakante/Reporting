from asyncio import base_events
from Utils.properties import BASE_URL, BASE_URL1

api1 = BASE_URL + '/api/v1/pingService/generateCommands'
api2 = BASE_URL + '/api/v1/pingService/generateCommands'
demoApi = BASE_URL1 + '/api/users?page=2'
usersApi = BASE_URL1 + '/api/users'