commands1 = ['ping 10.10.10.10 repeat 5 size 100 timeout 3 source gi0/0/1.3204']
commands2 = ['ping 127.0.0.1 repeat 5 size 100 timeout 3 source gi0/0/1.3204']