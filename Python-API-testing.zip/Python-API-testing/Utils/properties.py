import os
BASE_URL = os.getenv('PING_URL','http://localhost:3012')
BASE_URL1 = "https://reqres.in"