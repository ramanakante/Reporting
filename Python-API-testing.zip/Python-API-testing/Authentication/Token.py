
def generate_token():
    #code to generate token
    return "adsajdhsajdsajdsadsadsadksadksand"

# Auth_token = 'adasdadsadsadsadsadsadsadsa'